import sqlite3
import tkinter as tk
from tkinter import messagebox, simpledialog, scrolledtext
import subprocess

# Función para ejecutar comandos SQL
def ejecutar_sql(sql):
    try:
        conn = sqlite3.connect('/home/noa/proyecto/proyectoAinhoaAyoroa.db')
        cursor = conn.cursor()
        cursor.execute(sql)
        conn.commit()
        conn.close()
        messagebox.showinfo("Éxito", "Operación realizada exitosamente.")
    except Exception as e:
        messagebox.showerror("Error", f"Error al ejecutar la operación: {e}")

# Funciones para manipular la base de datos
def insertar_datos_libreria():
    cod_libreria = simpledialog.askinteger("Insertar Librería", "Ingrese el código de la librería:")
    direccion = simpledialog.askstring("Insertar Librería", "Ingrese la dirección de la librería:")
    tel = simpledialog.askstring("Insertar Librería", "Ingrese el teléfono de la librería:")
    if cod_libreria is not None and direccion and tel:
        sql = f"INSERT INTO Libreria (cod_libreria, direccion, tel) VALUES ({cod_libreria}, '{direccion}', '{tel}')"
        ejecutar_sql(sql)

def insertar_datos_libro():
    cod_libro = simpledialog.askinteger("Insertar Libro", "Ingrese el código del libro:")
    nombre = simpledialog.askstring("Insertar Libro", "Ingrese el nombre del libro:")
    autor = simpledialog.askstring("Insertar Libro", "Ingrese el autor del libro:")
    stock = simpledialog.askinteger("Insertar Libro", "Ingrese el stock del libro:")
    if cod_libro is not None and nombre and autor and stock is not None:
        sql = f"INSERT INTO Libro (cod_libro, nombre, autor, stock) VALUES ({cod_libro}, '{nombre}', '{autor}', {stock})"
        ejecutar_sql(sql)

def insertar_datos_ventas():
    cod_libreria = simpledialog.askinteger("Insertar Venta", "Ingrese el código de la librería:")
    cod_libro = simpledialog.askinteger("Insertar Venta", "Ingrese el código del libro:")
    precio = simpledialog.askfloat("Insertar Venta", "Ingrese el precio del libro:")
    cantidad = simpledialog.askinteger("Insertar Venta", "Ingrese la cantidad disponible del libro:")
    if cod_libreria is not None and cod_libro is not None and precio is not None and cantidad is not None:
        sql = f"INSERT INTO Vende (cod_libreria, cod_libro, precio, cantidad) VALUES ({cod_libreria}, {cod_libro}, {precio}, {cantidad})"
        ejecutar_sql(sql)

def actualizar_stock_libro():
    cod_libro = simpledialog.askinteger("Actualizar Stock", "Ingrese el código del libro:")
    nuevo_stock = simpledialog.askinteger("Actualizar Stock", "Ingrese el nuevo stock del libro:")
    if cod_libro is not None and nuevo_stock is not None:
        sql = f"UPDATE Libro SET stock = {nuevo_stock} WHERE cod_libro = {cod_libro}"
        ejecutar_sql(sql)

def actualizar_precio_libro_libreria():
    cod_libreria = simpledialog.askinteger("Actualizar Precio", "Ingrese el código de la librería:")
    cod_libro = simpledialog.askinteger("Actualizar Precio", "Ingrese el código del libro:")
    nuevo_precio = simpledialog.askfloat("Actualizar Precio", "Ingrese el nuevo precio del libro:")
    if cod_libreria is not None and cod_libro is not None and nuevo_precio is not None:
        sql = f"UPDATE Vende SET precio = {nuevo_precio} WHERE cod_libreria = {cod_libreria} AND cod_libro = {cod_libro}"
        ejecutar_sql(sql)

def eliminar_libreria_y_registros_relacionados():
    cod_libreria = simpledialog.askinteger("Eliminar Librería", "Ingrese el código de la librería:")
    if cod_libreria is not None:
        sql1 = f"DELETE FROM Libreria WHERE cod_libreria = {cod_libreria}"
        sql2 = f"DELETE FROM Vende WHERE cod_libreria = {cod_libreria}"
        ejecutar_sql(sql1)
        ejecutar_sql(sql2)

def eliminar_libro_y_registros_relacionados():
    cod_libro = simpledialog.askinteger("Eliminar Libro", "Ingrese el código del libro:")
    if cod_libro is not None:
        sql1 = f"DELETE FROM Libro WHERE cod_libro = {cod_libro}"
        sql2 = f"DELETE FROM Vende WHERE cod_libro = {cod_libro}"
        ejecutar_sql(sql1)
        ejecutar_sql(sql2)

def abrir_sqlite_browser():
    try:
        subprocess.run(['sqlitebrowser', '/home/noa/Documentos/proyectoAinhoaAyoroa.db'])
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo abrir SQLiteBrowser: {e}")

# Función para ejecutar una consulta SQL y mostrar los resultados
def consultar_datos(sql):
    try:
        conn = sqlite3.connect('/home/noa/Documentos/proyectoAinhoaAyoroa.db')
        cursor = conn.cursor()
        cursor.execute(sql)
        datos = cursor.fetchall()
        conn.close()

        # Crear ventana para mostrar los resultados
        ventana_resultados = tk.Toplevel()
        ventana_resultados.title("Resultados de la consulta")
        
        # Crear un widget de texto desplazable para mostrar los datos
        resultados_texto = scrolledtext.ScrolledText(ventana_resultados, width=50, height=20)
        resultados_texto.pack()
        
        # Mostrar los resultados en el widget de texto
        for fila in datos:
            resultados_texto.insert(tk.END, str(fila) + '\n')

    except Exception as e:
        messagebox.showerror("Error", f"Error al ejecutar la consulta: {e}")

# Crear la ventana principal
root = tk.Tk()
root.title("Operaciones de Base de Datos")

# Botones para manipular la base de datos
btn_insertar_libreria = tk.Button(root, text="Insertar datos en la tabla Librería", command=insertar_datos_libreria)
btn_insertar_libreria.pack()

btn_insertar_libro = tk.Button(root, text="Insertar datos en la tabla Libro", command=insertar_datos_libro)
btn_insertar_libro.pack()

btn_insertar_ventas = tk.Button(root, text="Insertar datos en la tabla Vende", command=insertar_datos_ventas)
btn_insertar_ventas.pack()

btn_actualizar_stock = tk.Button(root, text="Actualizar stock de un libro", command=actualizar_stock_libro)
btn_actualizar_stock.pack()

btn_actualizar_precio = tk.Button(root, text="Actualizar precio de un libro de una librería", command=actualizar_precio_libro_libreria)
btn_actualizar_precio.pack()

btn_eliminar_libreria = tk.Button(root, text="Eliminar una librería y sus registros relacionados de ventas", command=eliminar_libreria_y_registros_relacionados)
btn_eliminar_libreria.pack()

btn_eliminar_libro = tk.Button(root, text="Eliminar un libro y sus registros relacionados de ventas", command=eliminar_libro_y_registros_relacionados)
btn_eliminar_libro.pack()

btn_abrir_sqlite_browser = tk.Button(root, text="Abrir SQLiteBrowser", command=abrir_sqlite_browser)
btn_abrir_sqlite_browser.pack()

# Consultas de datos
lbl_consultas = tk.Label(root, text="Consultas de datos:")
lbl_consultas.pack()

btn_consultar_librerias = tk.Button(root, text="Seleccionar todas las librerías", 
                                    command=lambda: consultar_datos("SELECT * FROM Libreria"))
btn_consultar_librerias.pack()

btn_consultar_libros = tk.Button(root, text="Seleccionar todos los libros", 
                                 command=lambda: consultar_datos("SELECT * FROM Libro"))
btn_consultar_libros.pack()

btn_consultar_ventas = tk.Button(root, text="Seleccionar todas las ventas", 
                                 command=lambda: consultar_datos("SELECT * FROM Vende"))
btn_consultar_ventas.pack()

root.mainloop()


